import { useEffect, useMemo, useRef, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, Circle } from "react-leaflet";
import L from "leaflet";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { Incident, Severity } from "@/lib/types";
import { VENUE } from "@/lib/constants";

// Custom severity-colored markers using inline SVG (data URL).
const SEVERITY_HEX: Record<Severity, string> = {
  low: "#22c55e",
  medium: "#f59e0b",
  high: "#ef4444",
  critical: "#e11d48",
};

function pinIcon(severity: Severity, pulse = false) {
  const color = SEVERITY_HEX[severity];
  const ring = pulse
    ? `<circle cx="20" cy="20" r="18" fill="${color}" opacity="0.25"><animate attributeName="r" from="14" to="22" dur="1.6s" repeatCount="indefinite"/><animate attributeName="opacity" from="0.5" to="0" dur="1.6s" repeatCount="indefinite"/></circle>`
    : "";
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40">${ring}<circle cx="20" cy="20" r="9" fill="${color}" stroke="#0f1419" stroke-width="2"/><circle cx="20" cy="20" r="3" fill="#fff"/></svg>`;
  return L.divIcon({
    className: "",
    html: svg,
    iconSize: [40, 40],
    iconAnchor: [20, 20],
    popupAnchor: [0, -16],
  });
}

interface IncidentsMapProps {
  incidents: Incident[];
  selectedId?: string | null;
  onSelect?: (id: string) => void;
  height?: number;
}

export function IncidentsMap({ incidents, selectedId, onSelect, height = 420 }: IncidentsMapProps) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const active = useMemo(() => incidents.filter((i) => i.status !== "resolved"), [incidents]);
  const resolved = useMemo(() => incidents.filter((i) => i.status === "resolved"), [incidents]);

  // Re-trigger render when key resizes
  const containerRef = useRef<HTMLDivElement>(null);

  return (
    <Card className="overflow-hidden border-border/60 bg-card/60">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base">Venue map</CardTitle>
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            {(["critical", "high", "medium", "low"] as Severity[]).map((s) => (
              <span key={s} className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full" style={{ background: SEVERITY_HEX[s] }} />
                <span className="capitalize">{s}</span>
              </span>
            ))}
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div ref={containerRef} style={{ height }} className="w-full">
          {mounted && (
            <MapContainer
              center={[VENUE.center.lat, VENUE.center.lng]}
              zoom={17}
              scrollWheelZoom={false}
              className="h-full w-full"
              attributionControl
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>'
                url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
              />
              <Circle
                center={[VENUE.center.lat, VENUE.center.lng]}
                radius={VENUE.radiusMeters}
                pathOptions={{ color: "#ef4444", weight: 1, opacity: 0.4, fillOpacity: 0.05 }}
              />
              {active.map((i) => (
                <Marker
                  key={i.id}
                  position={[i.location.lat, i.location.lng]}
                  icon={pinIcon(i.severity, i.severity === "critical" || i.severity === "high")}
                  eventHandlers={{ click: () => onSelect?.(i.id) }}
                >
                  <Popup>
                    <div className="text-foreground">
                      <p className="text-xs uppercase tracking-wider opacity-70">{i.location.label ?? "Venue"}</p>
                      <p className="font-semibold capitalize">{i.type} · {i.severity}</p>
                      <p className="text-sm">{i.description}</p>
                      <p className="mt-1 text-xs opacity-70">Reporter: {i.reporterName}{i.reporterRoom ? ` (Room ${i.reporterRoom})` : ""}</p>
                    </div>
                  </Popup>
                </Marker>
              ))}
              {resolved.map((i) => (
                <Marker
                  key={i.id}
                  position={[i.location.lat, i.location.lng]}
                  icon={pinIcon(i.severity, false)}
                  opacity={0.45}
                />
              ))}
            </MapContainer>
          )}
          {selectedId && <span className="sr-only">Selected: {selectedId}</span>}
        </div>
      </CardContent>
    </Card>
  );
}
