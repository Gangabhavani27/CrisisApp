import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { Incident } from "@/lib/types";
import { Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { format } from "date-fns";

const TYPE_COLOR: Record<string, string> = {
  fire: "#f97316",
  medical: "#ef4444",
  security: "#3b82f6",
  evacuation: "#a855f7",
  other: "#6b7280",
};

const SEVERITY_COLOR: Record<string, string> = {
  low: "#22c55e",
  medium: "#f59e0b",
  high: "#ef4444",
  critical: "#e11d48",
};

const tooltipStyle = {
  contentStyle: {
    background: "hsl(220 24% 11%)",
    border: "1px solid hsl(220 18% 18%)",
    borderRadius: 12,
    color: "hsl(210 30% 96%)",
    fontSize: 12,
  },
  cursor: { fill: "hsl(220 20% 16%)" },
};

export function AnalyticsCharts({ incidents }: { incidents: Incident[] }) {
  const byType = useMemo(() => {
    const map: Record<string, number> = {};
    incidents.forEach((i) => { map[i.type] = (map[i.type] ?? 0) + 1; });
    return Object.entries(map).map(([type, count]) => ({ type, count, fill: TYPE_COLOR[type] ?? "#888" }));
  }, [incidents]);

  const bySeverity = useMemo(() => {
    const order = ["low", "medium", "high", "critical"];
    const map: Record<string, number> = {};
    incidents.forEach((i) => { map[i.severity] = (map[i.severity] ?? 0) + 1; });
    return order.map((s) => ({ severity: s, count: map[s] ?? 0, fill: SEVERITY_COLOR[s] }));
  }, [incidents]);

  const responseTrend = useMemo(() => {
    const resolved = incidents.filter((i) => i.status === "resolved" && i.resolvedAt);
    const buckets: Record<string, { day: string; avg: number; n: number; total: number }> = {};
    resolved.forEach((i) => {
      const day = format(i.createdAt, "MMM d");
      const mins = ((i.resolvedAt! - i.createdAt) / 60000);
      buckets[day] ??= { day, avg: 0, n: 0, total: 0 };
      buckets[day].total += mins;
      buckets[day].n += 1;
      buckets[day].avg = buckets[day].total / buckets[day].n;
    });
    return Object.values(buckets).slice(-7);
  }, [incidents]);

  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Card className="border-border/60 bg-card/60">
        <CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-muted-foreground">Incidents by type</CardTitle></CardHeader>
        <CardContent className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={byType} dataKey="count" nameKey="type" innerRadius={45} outerRadius={75} paddingAngle={3}>
                {byType.map((d) => <Cell key={d.type} fill={d.fill} stroke="hsl(220 24% 11%)" strokeWidth={2} />)}
              </Pie>
              <Tooltip {...tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 11, color: "hsl(215 16% 65%)" }} />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card className="border-border/60 bg-card/60">
        <CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-muted-foreground">Incidents by severity</CardTitle></CardHeader>
        <CardContent className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={bySeverity}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 18% 18%)" />
              <XAxis dataKey="severity" tick={{ fill: "hsl(215 16% 65%)", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "hsl(215 16% 65%)", fontSize: 11 }} axisLine={false} tickLine={false} allowDecimals={false} />
              <Tooltip {...tooltipStyle} />
              <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                {bySeverity.map((d) => <Cell key={d.severity} fill={d.fill} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card className="border-border/60 bg-card/60">
        <CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-muted-foreground">Avg response time (min)</CardTitle></CardHeader>
        <CardContent className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={responseTrend.length > 0 ? responseTrend : [{ day: "—", avg: 0, n: 0, total: 0 }]}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 18% 18%)" />
              <XAxis dataKey="day" tick={{ fill: "hsl(215 16% 65%)", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "hsl(215 16% 65%)", fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip {...tooltipStyle} />
              <Line type="monotone" dataKey="avg" stroke="hsl(0 84% 58%)" strokeWidth={2.5} dot={{ fill: "hsl(0 84% 58%)", r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}
