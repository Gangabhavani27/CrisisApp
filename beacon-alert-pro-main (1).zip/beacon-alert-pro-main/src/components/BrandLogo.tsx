import { Shield } from "lucide-react";
import { cn } from "@/lib/utils";

interface BrandLogoProps {
  className?: string;
  iconClassName?: string;
  textClassName?: string;
  showText?: boolean;
}

export function BrandLogo({ className, iconClassName, textClassName, showText = true }: BrandLogoProps) {
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <div className={cn("relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-emergency shadow-glow", iconClassName)}>
        <Shield className="h-5 w-5 text-primary-foreground" strokeWidth={2.5} />
      </div>
      {showText && (
        <div className={cn("flex flex-col leading-none", textClassName)}>
          <span className="font-bold tracking-tight text-foreground">CrisisShield</span>
          <span className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">AI Response</span>
        </div>
      )}
    </div>
  );
}
