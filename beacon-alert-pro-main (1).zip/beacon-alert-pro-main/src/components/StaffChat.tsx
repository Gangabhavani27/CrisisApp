import { useState } from "react";
import { useIncidentStore } from "@/lib/incident-store";
import { useAuthStore } from "@/lib/auth-store";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export function StaffChat() {
  const user = useAuthStore((s) => s.user)!;
  const chat = useIncidentStore((s) => s.chat);
  const post = useIncidentStore((s) => s.postChat);
  const [text, setText] = useState("");

  const send = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!text.trim()) return;
    post({ authorId: user.id, authorName: user.name, authorRole: user.role, text: text.trim().slice(0, 300) });
    setText("");
  };

  return (
    <Card className="flex h-[420px] flex-col border-border/60 bg-card/60">
      <CardHeader className="border-b border-border/40 pb-3">
        <CardTitle className="text-base">Staff channel</CardTitle>
      </CardHeader>
      <CardContent className="flex flex-1 flex-col gap-2 overflow-hidden p-0">
        <ScrollArea className="flex-1 px-4 py-3">
          <div className="space-y-3">
            {chat.length === 0 && <p className="text-center text-sm text-muted-foreground">No messages yet.</p>}
            {chat.map((m) => {
              const mine = m.authorId === user.id;
              const initials = m.authorName.split(" ").map((p) => p[0]).slice(0, 2).join("");
              return (
                <div key={m.id} className={`flex gap-2 ${mine ? "flex-row-reverse" : ""}`}>
                  <Avatar className="h-7 w-7 shrink-0">
                    <AvatarFallback className={`text-[10px] font-semibold ${mine ? "bg-gradient-emergency text-primary-foreground" : "bg-secondary"}`}>{initials}</AvatarFallback>
                  </Avatar>
                  <div className={`max-w-[80%] rounded-2xl px-3 py-2 text-sm ${mine ? "rounded-tr-sm bg-primary/15" : "rounded-tl-sm bg-secondary/60"}`}>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-medium">{mine ? "You" : m.authorName}</span>
                      <span className="text-[10px] capitalize text-muted-foreground">{m.authorRole}</span>
                    </div>
                    <p className="mt-0.5">{m.text}</p>
                    <p className="mt-1 text-[10px] text-muted-foreground">{formatDistanceToNow(m.createdAt, { addSuffix: true })}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </ScrollArea>
        <form onSubmit={send} className="flex gap-2 border-t border-border/40 p-3">
          <Input value={text} onChange={(e) => setText(e.target.value)} placeholder="Message the team…" maxLength={300} />
          <Button type="submit" size="icon" className="bg-gradient-emergency"><Send className="h-4 w-4" /></Button>
        </form>
      </CardContent>
    </Card>
  );
}
