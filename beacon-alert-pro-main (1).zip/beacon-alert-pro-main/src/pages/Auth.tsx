import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useAuthStore } from "@/lib/auth-store";
import { BrandLogo } from "@/components/BrandLogo";
import { toast } from "sonner";
import type { UserRole } from "@/lib/types";
import { Loader2 } from "lucide-react";

export default function AuthPage() {
  const nav = useNavigate();
  const [params] = useSearchParams();
  const login = useAuthStore((s) => s.login);
  const signup = useAuthStore((s) => s.signup);
  const loginAsDemo = useAuthStore((s) => s.loginAsDemo);
  const user = useAuthStore((s) => s.user);

  const [tab, setTab] = useState<"signin" | "signup">("signin");
  const [loading, setLoading] = useState(false);

  // Sign in
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // Sign up
  const [name, setName] = useState("");
  const [signupEmail, setSignupEmail] = useState("");
  const [signupPassword, setSignupPassword] = useState("");
  const [role, setRole] = useState<UserRole>("guest");
  const [room, setRoom] = useState("");
  const [department, setDepartment] = useState("");

  useEffect(() => {
    const demo = params.get("demo");
    if (demo === "guest" || demo === "staff" || demo === "admin") {
      loginAsDemo(demo);
      toast.success(`Signed in as demo ${demo}`);
      nav(demo === "guest" ? "/sos" : "/dashboard", { replace: true });
    }
  }, [params, loginAsDemo, nav]);

  useEffect(() => {
    if (user) nav(user.role === "guest" ? "/sos" : "/dashboard", { replace: true });
  }, [user, nav]);

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      const res = login(email, password);
      setLoading(false);
      if (res.ok === true) toast.success(`Welcome back, ${res.user.name.split(" ")[0]}`);
      else toast.error(res.error);
    }, 250);
  };

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    if (signupPassword.length < 6) return toast.error("Password must be at least 6 characters.");
    setLoading(true);
    setTimeout(() => {
      const res = signup({
        name,
        email: signupEmail,
        password: signupPassword,
        role,
        room: role === "guest" ? room || undefined : undefined,
        department: role !== "guest" ? department || "General" : undefined,
      });
      setLoading(false);
      if (res.ok === true) toast.success("Account created");
      else toast.error(res.error);
    }, 300);
  };

  const handleDemo = (r: UserRole) => {
    loginAsDemo(r);
    toast.success(`Signed in as demo ${r}`);
  };

  return (
    <div className="min-h-screen bg-gradient-shield">
      <div className="mx-auto flex min-h-screen max-w-md flex-col items-center justify-center px-4 py-12">
        <BrandLogo className="mb-8" />
        <Card className="w-full border-border/60 bg-card/70 shadow-elevated backdrop-blur-xl">
          <CardHeader>
            <CardTitle>Welcome to CrisisShield AI</CardTitle>
            <CardDescription>Sign in or create an account to access the emergency platform.</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={tab} onValueChange={(v) => setTab(v as "signin" | "signup")}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="signin">Sign in</TabsTrigger>
                <TabsTrigger value="signup">Create account</TabsTrigger>
              </TabsList>

              <TabsContent value="signin" className="mt-6">
                <form onSubmit={handleSignIn} className="space-y-4">
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@hotel.com" />
                  </div>
                  <div>
                    <Label htmlFor="password">Password</Label>
                    <Input id="password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
                  </div>
                  <Button type="submit" className="w-full bg-gradient-emergency" disabled={loading}>
                    {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                    Sign in
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="signup" className="mt-6">
                <form onSubmit={handleSignUp} className="space-y-4">
                  <div>
                    <Label htmlFor="name">Full name</Label>
                    <Input id="name" required value={name} onChange={(e) => setName(e.target.value)} maxLength={80} />
                  </div>
                  <div>
                    <Label htmlFor="signup-email">Email</Label>
                    <Input id="signup-email" type="email" required value={signupEmail} onChange={(e) => setSignupEmail(e.target.value)} maxLength={120} />
                  </div>
                  <div>
                    <Label htmlFor="signup-password">Password</Label>
                    <Input id="signup-password" type="password" required minLength={6} value={signupPassword} onChange={(e) => setSignupPassword(e.target.value)} />
                  </div>
                  <div>
                    <Label>I am a…</Label>
                    <RadioGroup value={role} onValueChange={(v) => setRole(v as UserRole)} className="mt-2 grid grid-cols-3 gap-2">
                      {(["guest", "staff", "admin"] as const).map((r) => (
                        <Label key={r} htmlFor={`r-${r}`} className={`flex cursor-pointer items-center justify-center gap-2 rounded-lg border border-border bg-secondary/40 p-3 text-sm capitalize transition-colors hover:bg-secondary ${role === r ? "border-primary bg-primary/10 text-primary" : ""}`}>
                          <RadioGroupItem id={`r-${r}`} value={r} className="sr-only" />
                          {r}
                        </Label>
                      ))}
                    </RadioGroup>
                  </div>
                  {role === "guest" ? (
                    <div>
                      <Label htmlFor="room">Room number</Label>
                      <Input id="room" value={room} onChange={(e) => setRoom(e.target.value)} maxLength={10} placeholder="e.g. 412" />
                    </div>
                  ) : (
                    <div>
                      <Label htmlFor="dept">Department</Label>
                      <Input id="dept" value={department} onChange={(e) => setDepartment(e.target.value)} maxLength={40} placeholder="Security, Medical, Operations…" />
                    </div>
                  )}
                  <Button type="submit" className="w-full bg-gradient-emergency" disabled={loading}>
                    {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                    Create account
                  </Button>
                </form>
              </TabsContent>
            </Tabs>

            <div className="mt-6">
              <div className="relative">
                <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-border" /></div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-card/70 px-2 text-muted-foreground">Or try a demo account</span>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-2">
                <Button variant="outline" size="sm" onClick={() => handleDemo("guest")}>Guest</Button>
                <Button variant="outline" size="sm" onClick={() => handleDemo("staff")}>Staff</Button>
                <Button variant="outline" size="sm" onClick={() => handleDemo("admin")}>Admin</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
