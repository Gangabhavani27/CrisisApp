import { useNavigate } from "react-router-dom";
import { ArrowRight, Activity, Brain, MapPin, MessageSquare, ShieldAlert, Users, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TopBar } from "@/components/TopBar";
import { useAuthStore } from "@/lib/auth-store";

const FEATURES = [
  { icon: ShieldAlert, title: "One-tap SOS", text: "Guests trigger help with location, type, and details captured instantly." },
  { icon: Brain, title: "AI prioritization", text: "Severity, panic clusters, and wait time fuel a smart triage score." },
  { icon: MapPin, title: "Live venue map", text: "See every active incident pinned in real time across the property." },
  { icon: Users, title: "Responder dispatch", text: "Assign on-call staff and track response from pending to resolved." },
  { icon: MessageSquare, title: "AI guidance chatbot", text: "Calm, step-by-step instructions for fire, medical, security and more." },
  { icon: Activity, title: "Operations analytics", text: "Trends, response times, and emergency-type breakdowns at a glance." },
];

export default function Landing() {
  const nav = useNavigate();
  const user = useAuthStore((s) => s.user);

  return (
    <div className="min-h-screen bg-gradient-shield">
      <TopBar />

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_hsl(0_84%_58%_/_0.15),_transparent_60%)]" aria-hidden />
        <div className="relative mx-auto max-w-[1200px] px-4 py-20 md:px-6 md:py-28">
          <Badge variant="outline" className="mb-6 border-primary/40 bg-primary/10 text-primary">
            <Zap className="mr-1.5 h-3 w-3" />
            Real-time crisis platform for hospitality
          </Badge>
          <h1 className="max-w-4xl text-4xl font-bold leading-[1.05] tracking-tight md:text-6xl lg:text-7xl">
            When seconds matter, <span className="text-gradient-emergency">CrisisShield</span> coordinates the response.
          </h1>
          <p className="mt-6 max-w-2xl text-lg text-muted-foreground md:text-xl">
            Hotels, resorts, and event venues use CrisisShield AI to detect emergencies the moment they happen, route the right responders, and keep guests informed — with zero communication gaps.
          </p>
          <div className="mt-10 flex flex-wrap items-center gap-3">
            {user ? (
              <Button size="lg" onClick={() => nav(user.role === "guest" ? "/sos" : "/dashboard")} className="bg-gradient-emergency text-primary-foreground shadow-glow hover:opacity-90">
                Continue to {user.role === "guest" ? "Guest App" : "Dashboard"}
                <ArrowRight />
              </Button>
            ) : (
              <>
                <Button size="lg" onClick={() => nav("/auth")} className="bg-gradient-emergency text-primary-foreground shadow-glow hover:opacity-90">
                  Get started
                  <ArrowRight />
                </Button>
                <Button size="lg" variant="outline" onClick={() => nav("/auth?demo=staff")}>
                  Live staff demo
                </Button>
              </>
            )}
          </div>

          {/* Live stats strip */}
          <div className="mt-16 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              { k: "<2s", v: "alert latency" },
              { k: "100%", v: "incident audit" },
              { k: "24/7", v: "AI triage" },
              { k: "4 langs", v: "guest UI" },
            ].map((s) => (
              <div key={s.v} className="rounded-2xl border border-border/60 bg-card/50 p-4 backdrop-blur">
                <div className="text-2xl font-bold text-gradient-emergency md:text-3xl">{s.k}</div>
                <div className="mt-1 text-xs uppercase tracking-wider text-muted-foreground">{s.v}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-[1200px] px-4 py-20 md:px-6">
        <div className="mb-12 max-w-2xl">
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">Everything an on-property emergency needs</h2>
          <p className="mt-3 text-muted-foreground">From the first guest tap to a fully resolved incident — coordinated, audited, and AI-assisted.</p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <div key={f.title} className="group rounded-2xl border border-border/60 bg-card/60 p-6 transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-glow">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-emergency shadow-glow">
                <f.icon className="h-5 w-5 text-primary-foreground" />
              </div>
              <h3 className="mt-5 text-lg font-semibold">{f.title}</h3>
              <p className="mt-1.5 text-sm text-muted-foreground">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-[1200px] px-4 pb-24 md:px-6">
        <div className="relative overflow-hidden rounded-3xl border border-primary/40 bg-card/70 p-10 text-center md:p-16">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_hsl(0_84%_58%_/_0.2),_transparent_70%)]" aria-hidden />
          <h2 className="relative text-3xl font-bold md:text-4xl">Ready to coordinate your next emergency in seconds?</h2>
          <p className="relative mx-auto mt-3 max-w-xl text-muted-foreground">Try the live guest app and operations dashboard with seeded demo data.</p>
          <div className="relative mt-8 flex flex-wrap justify-center gap-3">
            <Button size="lg" className="bg-gradient-emergency shadow-glow" onClick={() => nav("/auth")}>
              Launch demo
              <ArrowRight />
            </Button>
          </div>
        </div>
        <p className="mt-10 text-center text-xs text-muted-foreground">
          Demo accounts: <span className="font-mono">guest@demo.com</span> · <span className="font-mono">staff@demo.com</span> · <span className="font-mono">admin@demo.com</span> — password <span className="font-mono">demo1234</span>
        </p>
      </section>
    </div>
  );
}
