import { useEffect, useMemo, useRef, useState } from "react";
import { AlertCircle, Bot, CheckCircle2, DoorOpen, Flame, HeartPulse, Loader2, MapPin, Mic, Send, ShieldAlert, Sparkles, Timer } from "lucide-react";
import { TopBar } from "@/components/TopBar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useAuthStore } from "@/lib/auth-store";
import { useIncidentStore } from "@/lib/incident-store";
import type { EmergencyType, GeoLocation, Incident } from "@/lib/types";
import { EMERGENCY_META, VENUE } from "@/lib/constants";
import { severityBg } from "@/lib/ai";
import { getGuidance, type ChatbotReply } from "@/lib/chatbot";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";

const TYPE_ICONS: Record<EmergencyType, typeof Flame> = {
  fire: Flame,
  medical: HeartPulse,
  security: ShieldAlert,
  evacuation: DoorOpen,
  other: AlertCircle,
};

export default function GuestApp() {
  const user = useAuthStore((s) => s.user)!;
  const incidents = useIncidentStore((s) => s.incidents);
  const createIncident = useIncidentStore((s) => s.createIncident);

  const [selectedType, setSelectedType] = useState<EmergencyType | null>(null);
  const [details, setDetails] = useState("");
  const [location, setLocation] = useState<GeoLocation>({ ...VENUE.center, label: user.room ? `Room ${user.room}` : "Venue" });
  const [submitting, setSubmitting] = useState(false);
  const [confirmed, setConfirmed] = useState<Incident | null>(null);

  // Detect geolocation; fall back silently to venue center.
  useEffect(() => {
    if (!("geolocation" in navigator)) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => setLocation((l) => ({ ...l, lat: pos.coords.latitude, lng: pos.coords.longitude })),
      () => undefined,
      { timeout: 4000 }
    );
  }, []);

  // Voice input via Web Speech API (graceful fallback).
  const recognitionRef = useRef<unknown>(null);
  const [listening, setListening] = useState(false);
  const startVoice = () => {
    const SR = (window as unknown as { SpeechRecognition?: new () => unknown; webkitSpeechRecognition?: new () => unknown }).SpeechRecognition
      ?? (window as unknown as { webkitSpeechRecognition?: new () => unknown }).webkitSpeechRecognition;
    if (!SR) return toast.error("Voice input is not supported in this browser.");
    const rec = new SR() as { lang: string; interimResults: boolean; onresult: (e: { results: ArrayLike<{ 0: { transcript: string } }> }) => void; onend: () => void; start: () => void; stop: () => void };
    rec.lang = user.language === "es" ? "es-ES" : user.language === "fr" ? "fr-FR" : user.language === "de" ? "de-DE" : "en-US";
    rec.interimResults = false;
    rec.onresult = (e) => {
      const text = e.results[0][0].transcript;
      setDetails((d) => (d ? d + " " : "") + text);
    };
    rec.onend = () => setListening(false);
    recognitionRef.current = rec;
    setListening(true);
    rec.start();
  };
  const stopVoice = () => {
    (recognitionRef.current as { stop: () => void } | null)?.stop?.();
    setListening(false);
  };

  const handleSend = () => {
    if (!selectedType) return toast.error("Please select an emergency type.");
    setSubmitting(true);
    setTimeout(() => {
      const incident = createIncident({
        reporterId: user.id,
        reporterName: user.name,
        reporterRoom: user.room,
        type: selectedType,
        description: details.trim().slice(0, 500),
        location,
      });
      setSubmitting(false);
      setConfirmed(incident);
      setSelectedType(null);
      setDetails("");
    }, 700);
  };

  const myIncidents = useMemo(
    () => incidents.filter((i) => i.reporterId === user.id).sort((a, b) => b.createdAt - a.createdAt),
    [incidents, user.id]
  );

  return (
    <div className="min-h-screen bg-gradient-shield">
      <TopBar />
      <main className="mx-auto max-w-3xl px-4 py-8 md:py-12">
        {confirmed ? (
          <ConfirmationCard incident={confirmed} onDone={() => setConfirmed(null)} />
        ) : (
          <Card className="overflow-hidden border-border/60 bg-card/70 shadow-elevated backdrop-blur-xl">
            <CardHeader className="border-b border-border/40">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <CardTitle className="text-2xl">Emergency SOS</CardTitle>
                  <p className="mt-1 text-sm text-muted-foreground">Tap the button — we’ll capture your location and dispatch help.</p>
                </div>
                <Badge variant="outline" className="border-primary/40 bg-primary/10 text-primary">
                  <span className="mr-1.5 inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-primary" />
                  24/7 monitored
                </Badge>
              </div>
            </CardHeader>

            <CardContent className="space-y-8 p-6 md:p-8">
              {/* SOS Button */}
              <div className="flex flex-col items-center pt-4">
                <button
                  type="button"
                  onClick={handleSend}
                  disabled={submitting || !selectedType}
                  className="pulse-ring relative flex h-44 w-44 flex-col items-center justify-center rounded-full bg-gradient-emergency text-primary-foreground shadow-glow transition-all hover:scale-[1.03] active:scale-95 disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:scale-100"
                  aria-label="Send SOS"
                >
                  {submitting ? (
                    <Loader2 className="h-12 w-12 animate-spin" />
                  ) : (
                    <>
                      <ShieldAlert className="h-14 w-14" strokeWidth={2.2} />
                      <span className="mt-1 text-sm font-bold uppercase tracking-widest">SOS</span>
                    </>
                  )}
                </button>
                <p className="mt-4 text-center text-sm text-muted-foreground">
                  {selectedType ? `Send a ${EMERGENCY_META[selectedType].label.toLowerCase()} alert` : "Choose an emergency type below to enable SOS"}
                </p>
              </div>

              {/* Type picker */}
              <div>
                <p className="mb-3 text-sm font-medium">Choose emergency type</p>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
                  {(Object.keys(EMERGENCY_META) as EmergencyType[]).map((t) => {
                    const Icon = TYPE_ICONS[t];
                    const active = selectedType === t;
                    return (
                      <button
                        key={t}
                        type="button"
                        onClick={() => setSelectedType(t)}
                        className={`group flex flex-col items-center gap-2 rounded-xl border p-3 text-center transition-all ${active ? "border-primary bg-primary/15 text-primary shadow-glow" : "border-border bg-secondary/40 hover:border-primary/40 hover:bg-secondary"}`}
                      >
                        <Icon className="h-6 w-6" />
                        <span className="text-xs font-medium">{EMERGENCY_META[t].label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Details */}
              <div>
                <div className="mb-2 flex items-center justify-between">
                  <label htmlFor="details" className="text-sm font-medium">Add details (optional)</label>
                  <Button type="button" variant="ghost" size="sm" onClick={listening ? stopVoice : startVoice} className={listening ? "text-primary" : ""}>
                    <Mic className={`h-4 w-4 ${listening ? "animate-pulse" : ""}`} />
                    {listening ? "Listening…" : "Use voice"}
                  </Button>
                </div>
                <Textarea
                  id="details"
                  placeholder="e.g. Smoke in the hallway near the elevators on the 3rd floor"
                  value={details}
                  onChange={(e) => setDetails(e.target.value)}
                  maxLength={500}
                  rows={3}
                />
                <div className="mt-1 text-right text-xs text-muted-foreground">{details.length}/500</div>
              </div>

              <div className="grid gap-3 rounded-xl border border-border/60 bg-secondary/30 p-4 sm:grid-cols-2">
                <div className="flex items-start gap-3">
                  <MapPin className="mt-0.5 h-4 w-4 text-primary" />
                  <div className="min-w-0">
                    <p className="text-xs uppercase tracking-wider text-muted-foreground">Detected location</p>
                    <p className="truncate text-sm font-medium">{location.label ?? VENUE.name}</p>
                    <p className="text-xs text-muted-foreground">{location.lat.toFixed(4)}, {location.lng.toFixed(4)}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Timer className="mt-0.5 h-4 w-4 text-accent" />
                  <div>
                    <p className="text-xs uppercase tracking-wider text-muted-foreground">Estimated response</p>
                    <p className="text-sm font-medium">{selectedType ? `~${Math.ceil((EMERGENCY_META[selectedType].severity === "critical" ? 90 : EMERGENCY_META[selectedType].severity === "high" ? 180 : EMERGENCY_META[selectedType].severity === "medium" ? 360 : 600) / 60)} min` : "—"}</p>
                  </div>
                </div>
              </div>

              <Button type="button" size="lg" className="w-full bg-gradient-emergency" onClick={handleSend} disabled={submitting || !selectedType}>
                {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                Send alert
              </Button>
            </CardContent>
          </Card>
        )}

        {myIncidents.length > 0 && (
          <Card className="mt-6 border-border/60 bg-card/60">
            <CardHeader>
              <CardTitle className="text-base">Your recent alerts</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {myIncidents.slice(0, 5).map((i) => (
                <div key={i.id} className="flex items-center justify-between rounded-lg border border-border/40 p-3">
                  <div className="flex items-center gap-3">
                    <Badge variant="outline" className={severityBg(i.severity)}>{i.severity}</Badge>
                    <div>
                      <p className="text-sm font-medium capitalize">{EMERGENCY_META[i.type].label}</p>
                      <p className="text-xs text-muted-foreground">{formatDistanceToNow(i.createdAt, { addSuffix: true })}</p>
                    </div>
                  </div>
                  <Badge variant="secondary" className="capitalize">{i.status.replace("_", " ")}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        <GuidanceChatbot />
      </main>
    </div>
  );
}

function ConfirmationCard({ incident, onDone }: { incident: Incident; onDone: () => void }) {
  return (
    <Card className="overflow-hidden border-success/40 bg-card/70 shadow-elevated">
      <CardContent className="p-8 text-center">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-success/15">
          <CheckCircle2 className="h-9 w-9 text-success" />
        </div>
        <h2 className="mt-5 text-2xl font-bold">Help is on the way</h2>
        <p className="mt-2 text-muted-foreground">
          A <span className="capitalize">{EMERGENCY_META[incident.type].label.toLowerCase()}</span> alert was sent to the response team.
        </p>
        <div className="mx-auto mt-6 grid max-w-md grid-cols-2 gap-3 text-left">
          <div className="rounded-lg border border-border/60 bg-secondary/40 p-3">
            <p className="text-xs uppercase text-muted-foreground">Severity</p>
            <p className="mt-1 text-base font-semibold capitalize">{incident.severity}</p>
          </div>
          <div className="rounded-lg border border-border/60 bg-secondary/40 p-3">
            <p className="text-xs uppercase text-muted-foreground">ETA</p>
            <p className="mt-1 text-base font-semibold">~{Math.ceil(incident.estimatedResponseSec / 60)} min</p>
          </div>
        </div>
        {incident.panicCluster && (
          <div className="mt-4 rounded-lg border border-severity-critical/40 bg-severity-critical/10 p-3 text-sm text-severity-critical">
            Panic cluster detected — multiple alerts nearby. Crisis protocol engaged.
          </div>
        )}
        <Button onClick={onDone} variant="outline" className="mt-6">Send another alert</Button>
      </CardContent>
    </Card>
  );
}

function GuidanceChatbot() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [history, setHistory] = useState<{ q: string; a: ChatbotReply }[]>([]);

  const ask = (text?: string) => {
    const q = (text ?? input).trim();
    if (!q) return;
    const a = getGuidance(q);
    setHistory((h) => [...h, { q, a }]);
    setInput("");
  };

  return (
    <Card className="mt-6 border-border/60 bg-card/60">
      <CardHeader className="cursor-pointer" onClick={() => setOpen((o) => !o)}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-accent">
              <Bot className="h-5 w-5 text-accent-foreground" />
            </div>
            <div>
              <CardTitle className="text-base">AI Emergency Guidance</CardTitle>
              <p className="text-xs text-muted-foreground">Ask what to do during fire, medical, security incidents…</p>
            </div>
          </div>
          <Sparkles className="h-4 w-4 text-accent" />
        </div>
      </CardHeader>
      {open && (
        <CardContent className="space-y-4">
          {history.length === 0 && (
            <div className="grid grid-cols-2 gap-2 text-sm">
              {["What to do during a fire?", "Someone is unconscious", "Suspicious person on my floor", "How to evacuate?"].map((s) => (
                <button key={s} type="button" onClick={() => ask(s)} className="rounded-lg border border-border bg-secondary/40 p-3 text-left transition-colors hover:bg-secondary">
                  {s}
                </button>
              ))}
            </div>
          )}
          <div className="space-y-4">
            {history.map((h, idx) => (
              <div key={idx} className="space-y-2">
                <div className="flex justify-end"><div className="max-w-[80%] rounded-2xl rounded-tr-sm bg-primary/15 px-4 py-2 text-sm text-foreground">{h.q}</div></div>
                <div className="flex"><div className="max-w-[90%] rounded-2xl rounded-tl-sm border border-border/60 bg-secondary/40 px-4 py-3">
                  <p className="font-semibold text-accent">{h.a.title}</p>
                  <ol className="mt-2 list-inside list-decimal space-y-1 text-sm text-foreground/90">
                    {h.a.steps.map((s, i) => <li key={i}>{s}</li>)}
                  </ol>
                  {h.a.warning && <p className="mt-3 rounded-md border border-warning/40 bg-warning/10 p-2 text-xs text-warning">⚠ {h.a.warning}</p>}
                </div></div>
              </div>
            ))}
          </div>
          <div className="flex gap-2">
            <Textarea value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask for guidance…" rows={1} className="min-h-[44px] resize-none" onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); ask(); } }} />
            <Button type="button" onClick={() => ask()} className="bg-gradient-accent text-accent-foreground"><Send className="h-4 w-4" /></Button>
          </div>
        </CardContent>
      )}
    </Card>
  );
}
