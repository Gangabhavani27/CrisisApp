/** Lightweight rule-based emergency guidance "AI". Returns step-by-step advice
 *  for the most common hospitality emergencies. Triggered by chat input. */

export interface ChatbotReply {
  title: string;
  steps: string[];
  warning?: string;
}

const GUIDES: { match: RegExp; reply: ChatbotReply }[] = [
  {
    match: /\b(fire|smoke|burn|flame)\b/i,
    reply: {
      title: "Fire / Smoke Emergency",
      steps: [
        "Pull the nearest fire alarm if you haven't already.",
        "Stay low to avoid smoke; cover your nose and mouth with cloth.",
        "Use the nearest stairwell — never elevators.",
        "Touch doors before opening; if hot, find another route.",
        "Once outside, move to the assembly point and stay there.",
      ],
      warning: "If you cannot leave, seal door cracks with wet towels and signal from a window.",
    },
  },
  {
    match: /\b(medical|injury|hurt|bleed|unconscious|cpr|heart|breath)\b/i,
    reply: {
      title: "Medical Emergency",
      steps: [
        "Check the scene is safe before approaching.",
        "Tap the person and ask loudly if they are okay.",
        "If unresponsive and not breathing normally, begin CPR (100–120 compressions/min).",
        "Apply firm pressure to any heavy bleeding using clean cloth.",
        "Stay on the line — keep the person still and warm.",
      ],
      warning: "Do not move someone with a suspected spinal injury unless they are in immediate danger.",
    },
  },
  {
    match: /\b(security|intruder|theft|weapon|threat|fight|attack|suspicious)\b/i,
    reply: {
      title: "Security Threat",
      steps: [
        "Move to a safe location away from the threat — do not engage.",
        "If safe, lock the nearest door and silence your phone.",
        "Stay low and out of sight from windows and doors.",
        "Note descriptions: clothing, height, direction of travel.",
        "Wait for the all-clear from staff or law enforcement before moving.",
      ],
    },
  },
  {
    match: /\b(evacuat|leave|exit|escape|trapped)\b/i,
    reply: {
      title: "Evacuation Guidance",
      steps: [
        "Stay calm and follow illuminated exit signs.",
        "Use stairs, never elevators.",
        "Help those around you who need assistance, if it is safe.",
        "Proceed directly to the designated assembly area.",
        "Do not re-enter the building until staff give the all-clear.",
      ],
    },
  },
  {
    match: /\b(earthquake|shake|tremor)\b/i,
    reply: {
      title: "Earthquake Safety",
      steps: [
        "Drop to the ground immediately.",
        "Take cover under a sturdy table or against an interior wall.",
        "Hold on until the shaking stops.",
        "Stay away from windows, mirrors, and heavy hanging objects.",
        "After shaking stops, evacuate via stairs and watch for aftershocks.",
      ],
    },
  },
  {
    match: /\b(flood|water|leak)\b/i,
    reply: {
      title: "Flooding / Water Emergency",
      steps: [
        "Move to higher ground or an upper floor.",
        "Avoid contact with electrical outlets in wet areas.",
        "Do not walk through fast-moving water.",
        "Report the source and severity to staff immediately.",
      ],
    },
  },
];

export function getGuidance(input: string): ChatbotReply {
  for (const g of GUIDES) {
    if (g.match.test(input)) return g.reply;
  }
  return {
    title: "General Emergency Guidance",
    steps: [
      "Stay calm — take a deep breath.",
      "Tap the SOS button to alert response teams instantly.",
      "Move to a safe location away from immediate danger.",
      "Wait for trained responders — help is on the way.",
      "If you can, tell us more so we can dispatch the right team.",
    ],
    warning: "If this is life-threatening, call your local emergency number immediately.",
  };
}
