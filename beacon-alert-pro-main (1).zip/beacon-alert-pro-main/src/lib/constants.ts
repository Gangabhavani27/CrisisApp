import type { EmergencyType, Severity } from "./types";

// Venue: a fictitious resort. Center coords used for map + geo simulation.
export const VENUE = {
  name: "Azure Bay Resort & Spa",
  center: { lat: 25.7617, lng: -80.1918 }, // Miami-ish
  radiusMeters: 350,
};

// Emergency type metadata: icon name, label, default severity, color token.
export const EMERGENCY_META: Record<
  EmergencyType,
  { label: string; severity: Severity; description: string; icon: string }
> = {
  fire: {
    label: "Fire / Smoke",
    severity: "high",
    description: "Flames, smoke, or burning smell",
    icon: "Flame",
  },
  medical: {
    label: "Medical",
    severity: "high",
    description: "Injury, illness, or unresponsive person",
    icon: "HeartPulse",
  },
  security: {
    label: "Security",
    severity: "medium",
    description: "Intruder, theft, threat, or altercation",
    icon: "ShieldAlert",
  },
  evacuation: {
    label: "Evacuation",
    severity: "critical",
    description: "Need help leaving the area immediately",
    icon: "DoorOpen",
  },
  other: {
    label: "Other",
    severity: "low",
    description: "Something else needs attention",
    icon: "AlertCircle",
  },
};

export const SEVERITY_META: Record<
  Severity,
  { label: string; color: string; weight: number }
> = {
  low: { label: "Low", color: "severity-low", weight: 1 },
  medium: { label: "Medium", color: "severity-medium", weight: 2 },
  high: { label: "High", color: "severity-high", weight: 3 },
  critical: { label: "Critical", color: "severity-critical", weight: 4 },
};

export const STATUS_META = {
  pending: { label: "Pending", color: "warning" },
  in_progress: { label: "In Progress", color: "info" },
  resolved: { label: "Resolved", color: "success" },
} as const;

export const LANGUAGES = {
  en: "English",
  es: "Español",
  fr: "Français",
  de: "Deutsch",
} as const;
