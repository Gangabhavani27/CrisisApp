import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { User, UserRole, Language } from "./types";

interface AuthState {
  user: User | null;
  users: Record<string, { password: string; user: User }>;
  signup: (data: {
    name: string;
    email: string;
    password: string;
    role: UserRole;
    room?: string;
    department?: string;
  }) => { ok: true } | { ok: false; error: string };
  login: (email: string, password: string) => { ok: true; user: User } | { ok: false; error: string };
  logout: () => void;
  setLanguage: (language: Language) => void;
  loginAsDemo: (role: UserRole) => void;
}

const seedUsers: Record<string, { password: string; user: User }> = {
  "guest@demo.com": {
    password: "demo1234",
    user: {
      id: "u-guest-demo",
      name: "Alex Rivera",
      email: "guest@demo.com",
      role: "guest",
      room: "412",
      language: "en",
    },
  },
  "staff@demo.com": {
    password: "demo1234",
    user: {
      id: "u-staff-demo",
      name: "Jordan Chen",
      email: "staff@demo.com",
      role: "staff",
      department: "Security",
      language: "en",
    },
  },
  "admin@demo.com": {
    password: "demo1234",
    user: {
      id: "u-admin-demo",
      name: "Sam Okafor",
      email: "admin@demo.com",
      role: "admin",
      department: "Operations",
      language: "en",
    },
  },
};

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      users: seedUsers,
      signup: ({ name, email, password, role, room, department }) => {
        const key = email.toLowerCase().trim();
        if (get().users[key]) return { ok: false, error: "An account with that email already exists." };
        const user: User = {
          id: `u-${Date.now()}`,
          name: name.trim(),
          email: key,
          role,
          room,
          department,
          language: "en",
        };
        set((s) => ({
          users: { ...s.users, [key]: { password, user } },
          user,
        }));
        return { ok: true };
      },
      login: (email, password) => {
        const key = email.toLowerCase().trim();
        const record = get().users[key];
        if (!record) return { ok: false, error: "No account found with that email." };
        if (record.password !== password) return { ok: false, error: "Incorrect password." };
        set({ user: record.user });
        return { ok: true, user: record.user };
      },
      logout: () => set({ user: null }),
      setLanguage: (language) => {
        const u = get().user;
        if (!u) return;
        const updated = { ...u, language };
        set((s) => ({
          user: updated,
          users: { ...s.users, [u.email]: { ...s.users[u.email], user: updated } },
        }));
      },
      loginAsDemo: (role) => {
        const map = { guest: "guest@demo.com", staff: "staff@demo.com", admin: "admin@demo.com" } as const;
        const record = get().users[map[role]];
        if (record) set({ user: record.user });
      },
    }),
    {
      name: "crisisshield-auth",
      partialize: (s) => ({ users: s.users, user: s.user }),
    }
  )
);
